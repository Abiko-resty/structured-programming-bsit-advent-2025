Create database HOSPITAL;
//solution to question one
Use HOSPITAL;
CREATE TABLE DOCTOR ()

select view abc as select * from doc where dname like 'm%';
