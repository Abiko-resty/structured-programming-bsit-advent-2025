import axios from "axios";
import { v4 as uuidv4 } from "uuid";

/*
  Mock API for development.
  Replace with real backend endpoints by setting BASE_URL and dropping the mock layer.
*/

const BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:4000/api";

const client = axios.create({
  baseURL: BASE_URL,
});

export const api = {
  setToken(token) {
    client.defaults.headers.common.Authorization = `Bearer ${token}`;
  },
  clearToken() {
    delete client.defaults.headers.common.Authorization;
  },
  // Real backend call would use axios; mock below simulates server
  async login({ email, password }) {
    // Replace with axios post: await client.post("/auth/login", { email, password });
    // Simple mock:
    if (email === "student@ucu.ac.ug" && password === "password") {
      return {
        token: "mock-jwt-token",
        user: { id: "u-1", name: "Student", role: "student", email },
      };
    }
    if (email === "supervisor@ucu.ac.ug" && password === "password") {
      return {
        token: "mock-jwt-token",
        user: { id: "u-2", name: "Supervisor", role: "supervisor", email },
      };
    }
    if (email === "admin@ucu.ac.ug" && password === "password") {
      return {
        token: "mock-jwt-token",
        user: { id: "u-3", name: "Admin", role: "admin", email },
      };
    }
    return { error: "Invalid credentials" };
  },
  async register(payload) {
    // Simulated registration
    const user = { id: uuidv4(), ...payload, role: payload.role || "student" };
    return { token: "mock-jwt-token", user };
  },
  async getProjects() {
    // Simulated dataset
    return [
      {
        id: "p1",
        title: "Solar-Powered IoT Monitor",
        description: "Monitoring environmental data on a low-cost solar kit.",
        faculty: "Engineering",
        department: "Computing",
        category: "IoT",
        year: 2025,
        technologies: ["Node.js", "React", "MQTT"],
        approved: true,
        author: { id: "u-1", name: "Student A" },
      },
      {
        id: "p2",
        title: "Mobile Health Tracker",
        description: "A cross-platform app for tracking vital signs.",
        faculty: "Health",
        department: "Nursing",
        category: "Mobile",
        year: 2024,
        technologies: ["Flutter", "Firebase"],
        approved: true,
        author: { id: "u-4", name: "Student B" },
      },
    ];
  },
  async submitProject(data) {
    // Simulate server-side creation
    const newProject = { id: uuidv4(), ...data, approved: false, createdAt: new Date().toISOString() };
    return newProject;
  },
  async getSubmissions() {
    // Return mock queue (unapproved)
    return [
      {
        id: "p3",
        title: "Smart Agriculture System",
        description: "Automation for greenhouse environment control.",
        approved: false,
        author: { id: "u-5", name: "Student C" },
      },
    ];
  },
  async approveProject(projectId) {
    // simulate
    return { ok: true, projectId };
  },
  async analytics() {
    return {
      byFaculty: { Engineering: 12, Health: 5, Business: 3 },
      trendingTech: ["React", "Node.js", "Flutter"],
      approvals: { total: 20, approved: 15, pending: 5 },
    };
  },
};