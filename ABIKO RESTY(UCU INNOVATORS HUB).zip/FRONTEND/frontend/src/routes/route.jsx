import React from "react";
import { createBrowserRouter, Navigate } from "react-router-dom";
import MainLayout from "../layouts/MainLayout";
import DashboardLayout from "../layouts/DashboardLayout";
import Home from "../pages/Home";
import Gallery from "../pages/Projects/Gallery";
import SubmitProject from "../pages/Projects/SubmitProject";
import ReviewQueue from "../pages/Review/ReviewQueue";
import AdminDashboard from "../pages/Admin/AdminDashboard";
import Analytics from "../pages/Analytics/Analytics";
import Login from "../pages/Auth/Login";
import Register from "../pages/Auth/Register";
import RequireAuth from "../components/RequireAuth";

export const router = createBrowserRouter([
  {
    element: <MainLayout />,
    children: [
      { path: "/", element: <Home /> },
      { path: "/projects", element: <Gallery /> },
      { path: "/analytics", element: <Analytics /> },
      { path: "/login", element: <Login /> },
      { path: "/register", element: <Register /> },
    ],
  },
  {
    path: "/dashboard",
    element: (
      <RequireAuth>
        <DashboardLayout />
      </RequireAuth>
    ),
    children: [
      { index: true, element: <Navigate to="/dashboard/submit" replace /> },
      { path: "submit", element: <SubmitProject /> },
      { path: "review", element: <ReviewQueue /> },
      { path: "admin", element: <AdminDashboard /> },
    ],
  },
]);