import React from "react";
import { NavLink, Outlet } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import "../styles/global.css";

export default function MainLayout() {
  const { user, logout } = useAuth();

  return (
    <div>
      <header className="header">
        <div className="brand">UCU Innovators Hub</div>
        <nav>
          <NavLink to="/" end>Home</NavLink>
          <NavLink to="/projects">Projects</NavLink>
          <NavLink to="/analytics">Analytics</NavLink>
          {user ? (
            <>
              <NavLink to="/dashboard">Dashboard</NavLink>
              <button className="btn secondary" style={{ marginLeft: 8 }} onClick={logout}>Logout</button>
            </>
          ) : (
            <>
              <NavLink to="/login" style={{ marginLeft: 8 }}>Login</NavLink>
              <NavLink to="/register" style={{ marginLeft: 8 }}>Register</NavLink>
            </>
          )}
        </nav>
      </header>

      <main className="container" style={{ paddingTop: 24 }}>
        <Outlet />
      </main>

      <footer className="footer">
        © {new Date().getFullYear()} UCU Innovators Hub — Team Project
      </footer>
    </div>
  );
}