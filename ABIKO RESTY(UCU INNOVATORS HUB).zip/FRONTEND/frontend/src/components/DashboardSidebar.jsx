import React from "react";
import { NavLink } from "react-router-dom";
import { useAuth } from "../context/authContext"; // match existing file authContext.jsx

export default function DashboardSidebar() {
  const { user, logout } = useAuth();

  return (
    <aside style={{ width: 260, padding: 20 }}>
      <div style={{ marginBottom: 10, fontWeight: 700, color: "var(--accent)" }}>Dashboard</div>
      <div style={{ marginBottom: 10 }}>Hello, {user?.name || "User"}</div>
      <nav style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        <NavLink to="/dashboard/submit">Submit Project</NavLink>
        <NavLink to="/dashboard/review">Review Queue</NavLink>
        {user?.role === "admin" && <NavLink to="/dashboard/admin">Admin</NavLink>}
      </nav>
      <div style={{ marginTop: "auto", marginTop: 24 }}>
        <button className="btn secondary" onClick={logout}>Logout</button>
      </div>
    </aside>
  );
}