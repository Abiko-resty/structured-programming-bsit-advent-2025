import React from "react";
import { NavLink } from "react-router-dom";
import { useAuth } from "../context/authContext";

export default function Header() {
  const { user, logout } = useAuth();

  return (
    <header className="header" style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
      <div className="brand">UCU Innovators Hub</div>
      <nav>
        <NavLink to="/" end style={{ marginRight: 12 }}>Home</NavLink>
        <NavLink to="/projects" style={{ marginRight: 12 }}>Projects</NavLink>
        <NavLink to="/analytics" style={{ marginRight: 12 }}>Analytics</NavLink>
        {user ? (
          <>
            <NavLink to="/dashboard" style={{ marginRight: 12 }}>Dashboard</NavLink>
            <button className="btn secondary" onClick={logout}>Logout</button>
          </>
        ) : (
          <>
            <NavLink to="/login" style={{ marginRight: 12 }}>Login</NavLink>
            <NavLink to="/register">Register</NavLink>
          </>
        )}
      </nav>
    </header>
  );  
}