import React from "react";
import { NavLink, Outlet } from "react-router-dom";
import { useAuth } from "../context/authContext"; // match existing file authContext.jsx
import "../styles/global.css";

export default function DashboardLayout() {
  const { user, logout } = useAuth();

  return (
    <div style={{ display: "flex", minHeight: "80vh" }}>
      <aside style={{ width: 260, padding: 20 }}>
        <div style={{ marginBottom: 10, fontWeight: 700, color: "var(--accent)" }}>Dashboard</div>
        <div style={{ marginBottom: 10 }}>Hello, {user?.name || "User"}</div>
        <nav style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          <NavLink to="/dashboard/submit">Submit Project</NavLink>
          <NavLink to="/dashboard/review">Review Queue</NavLink>
          {user?.role === "admin" && <NavLink to="/dashboard/admin">Admin</NavLink>}
        </nav>
        <div style={{ marginTop: "auto", marginTop: 24 }}>
          <button className="btn secondary" onClick={logout}>Logout</button>
        </div>
      </aside>

      <div style={{ flex: 1, padding: 24 }}>
        <div className="card" style={{ marginBottom: 12 }}>
          <div style={{ fontWeight: 700 }}>Dashboard Panel</div>
          <div style={{ color: "var(--muted)", marginTop: 6 }}>
            Use the dashboard to manage submissions, approvals, and analytics.
          </div>
        </div>

        <section>
          <Outlet />
        </section>
      </div>
    </div>
  );
}