import React, { createContext, useState, useEffect, useContext } from "react";
import { api } from "../services/api";

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const stored = localStorage.getItem("uct_user");
    return stored ? JSON.parse(stored) : null;
  });
  const [token, setToken] = useState(() => localStorage.getItem("uct_token"));

  useEffect(() => {
    if (token) {
      api.setToken(token);
    } else {
      api.clearToken();
    }
  }, [token]);

  const login = async ({ email, password }) => {
    const res = await api.login({ email, password });
    if (res?.token) {
      setToken(res.token);
      setUser(res.user);
      localStorage.setItem("uct_token", res.token);
      localStorage.setItem("uct_user", JSON.stringify(res.user));
      api.setToken(res.token);
      return { ok: true };
    }
    return { ok: false, error: res?.error || "Login failed" };
  };

  const register = async (payload) => {
    const res = await api.register(payload);
    if (res?.token) {
      setToken(res.token);
      setUser(res.user);
      localStorage.setItem("uct_token", res.token);
      localStorage.setItem("uct_user", JSON.stringify(res.user));
      api.setToken(res.token);
      return { ok: true };
    }
    return { ok: false, error: res?.error || "Registration failed" };
  };

  const logout = () => {
    setToken(null);
    setUser(null);
    localStorage.removeItem("uct_token");
    localStorage.removeItem("uct_user");
    api.clearToken();
  };

  return (
    <AuthContext.Provider value={{ user, token, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}