import React, { useEffect, useState } from "react";
import ProjectCard from "./ProjectCard";
import { api } from "../../services/api";

export default function Gallery() {
  const [projects, setProjects] = useState([]);

  useEffect(() => {
    let mounted = true;
    (async () => {
      const res = await api.getProjects();
      if (mounted) setProjects(res || []);
    })();
    return () => {
      mounted = false;
    };
  }, []);

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12 }}>
        <h2>Projects</h2>
        <div style={{ color: "var(--muted)" }}>Showing {projects.length} approved projects</div>
      </div>
      <div className="grid">
        {projects.map((p) => (
          <ProjectCard key={p.id} project={p} />
        ))}
      </div>
    </div>
  );
}