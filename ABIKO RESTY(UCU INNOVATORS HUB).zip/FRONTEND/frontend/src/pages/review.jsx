import React, { useEffect, useState } from "react";
import { api } from "../../services/api";
import { useAuth } from "../../context/AuthContext";

export default function ReviewQueue() {
  const [queue, setQueue] = useState([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  useEffect(() => {
    let mounted = true;
    (async () => {
      const res = await api.getSubmissions();
      if (mounted) setQueue(res || []);
      setLoading(false);
    })();
    return () => {
      mounted = false;
    };
  }, []);

  const handleApprove = async (id) => {
    await api.approveProject(id);
    setQueue((prev) => prev.filter((p) => p.id !== id));
  };

  if (loading) return <div className="card">Loading queue...</div>;

  return (
    <div>
      <h2>Review Queue</h2>
      {queue.length === 0 && <div className="card">No submissions awaiting review</div>}
      <div style={{ display: "grid", gap: 12 }}>
        {queue.map((p) => (
          <div key={p.id} className="card">
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <div>
                <div style={{ fontWeight: 700 }}>{p.title}</div>
                <div style={{ color: "var(--muted)" }}>By {p.author?.name}</div>
                <p>{p.description}</p>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {user?.role === "supervisor" || user?.role === "admin" ? (
                  <>
                    <button className="btn" onClick={() => handleApprove(p.id)}>Approve</button>
                    <button className="btn secondary">Comment</button>
                  </>
                ) : (
                  <div style={{ color: "var(--muted)" }}>Unauthorized</div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}