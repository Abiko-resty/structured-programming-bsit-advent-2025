import React, { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";

export default function Login() {
  const { login } = useAuth();
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState(null);
  const navigate = useNavigate();
  const location = useLocation();
  const from = (location.state && location.state.from?.pathname) || "/dashboard";

  const change = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setError(null);
    const res = await login(form);
    if (res.ok) navigate(from, { replace: true });
    else setError(res.error);
  };

  return (
    <div style={{ maxWidth: 520, margin: "0 auto" }}>
      <h2>Login</h2>
      <form className="card" onSubmit={submit}>
        <div className="form-row">
          <label>Email</label>
          <input name="email" onChange={change} value={form.email} type="email" required />
        </div>
        <div className="form-row">
          <label>Password</label>
          <input name="password" onChange={change} value={form.password} type="password" required />
        </div>
        {error && <div style={{ color: "red", marginBottom: 8 }}>{error}</div>}
        <div style={{ display: "flex", gap: 8 }}>
          <button type="submit" className="btn">Login</button>
        </div>
      </form>
      <div style={{ marginTop: 12 }}>
        <div style={{ color: "var(--muted)" }}>Use demo logins: student@ucu.ac.ug/password, supervisor@ucu.ac.ug/password, admin@ucu.ac.ug/password</div>
      </div>
    </div>
  );
}