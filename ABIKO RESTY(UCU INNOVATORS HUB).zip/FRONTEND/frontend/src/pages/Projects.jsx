import React from "react";

export default function ProjectCard({ project }) {
  return (
    <div className="card">
      <h3>{project.title}</h3>
      <div style={{ fontSize: 13, color: "var(--muted)" }}>
        {project.faculty} — {project.year}
      </div>
      <p>{project.description}</p>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        {project.technologies?.map((t) => (
          <span key={t} style={{ background: "#eef6ff", color: "var(--accent)", padding: "4px 8px", borderRadius: 6, fontSize: 12 }}>
            {t}
          </span>
        ))}
      </div>
    </div>
  );
}