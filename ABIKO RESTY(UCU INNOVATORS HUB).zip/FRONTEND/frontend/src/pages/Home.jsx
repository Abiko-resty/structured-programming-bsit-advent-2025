import React from "react";
import { Link } from "react-router-dom";

export default function Home() {
  return (
    <div>
      <div className="card">
        <h2>Welcome to UCU Innovators Hub</h2>
        <p>
          A central repository for student projects and innovations across UCU.
          Submit projects, collaborate, and gain visibility.
        </p>
        <Link to="/projects" className="btn" style={{ marginTop: 8, display: "inline-block" }}>
          Explore Projects
        </Link>
      </div>

      <div style={{ marginTop: 16 }} className="grid">
        <div className="card">
          <h3>For Students</h3>
          <p>Submit your project ideas and documentation, receive feedback and approvals.</p>
        </div>
        <div className="card">
          <h3>For Supervisors</h3>
          <p>Review, comment and approve submissions from your students.</p>
        </div>
        <div className="card">
          <h3>For Admins</h3>
          <p>Manage categories, users, and analytics for enables decision-making.</p>
        </div>
      </div>
    </div>
  );
}