import React, { useEffect, useState } from "react";
import { api } from "../../services/api";
import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(CategoryScale, LinearScale, BarElement, Tooltip, Legend);

export default function AdminDashboard() {
  const [data, setData] = useState(null);

  useEffect(() => {
    (async () => {
      const res = await api.analytics();
      setData(res);
    })();
  }, []);

  if (!data) return <div className="card">Loading analytics...</div>;

  const labels = Object.keys(data.byFaculty);
  const counts = labels.map((l) => data.byFaculty[l]);

  const chartData = {
    labels,
    datasets: [
      {
        label: "Projects per Faculty",
        data: counts,
        backgroundColor: "rgba(35, 102, 163, 0.7)",
      },
    ],
  };

  return (
    <div>
      <h2>Admin Dashboard</h2>
      <div className="card" style={{ marginBottom: 12 }}>
        <div><strong>Totals</strong></div>
        <div style={{ display: "flex", gap: 12, marginTop: 8 }}>
          <div className="card"><div style={{ fontWeight: 700 }}>{data.approvals.total}</div><div style={{ color: "var(--muted)" }}>Total Projects</div></div>
          <div className="card"><div style={{ fontWeight: 700 }}>{data.approvals.approved}</div><div style={{ color: "var(--muted)" }}>Approved</div></div>
          <div className="card"><div style={{ fontWeight: 700 }}>{data.approvals.pending}</div><div style={{ color: "var(--muted)" }}>Pending</div></div>
        </div>
      </div>

      <div className="card">
        <Bar data={chartData} />
      </div>
    </div>
  );
}