import React, { useEffect, useState } from "react";
import { api } from "../../services/api";

export default function Analytics() {
  const [insights, setInsights] = useState(null);

  useEffect(() => {
    (async () => {
      const res = await api.analytics();
      setInsights(res);
    })();
  }, []);

  if (!insights) return <div className="card">Loading analytics...</div>;

  return (
    <div>
      <h2>Analytics</h2>
      <div className="card">
        <div style={{ fontWeight: 700 }}>Trending Technologies</div>
        <div style={{ marginTop: 8, display: "flex", gap: 8 }}>
          {insights.trendingTech.map((t) => (
            <div key={t} style={{ background: "#eef6ff", padding: "6px 8px", borderRadius: 6 }}>{t}</div>
          ))}
        </div>
      </div>
    </div>
  );
}