import React, { useState } from "react";
import { api } from "../../services/api";
import { useAuth } from "../../context/AuthContext";

export default function SubmitProject() {
  const { user } = useAuth();
  const [form, setForm] = useState({
    title: "",
    description: "",
    category: "",
    faculty: "",
    department: "",
    year: new Date().getFullYear(),
    technologies: "",
    github: "",
  });
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    const payload = {
      ...form,
      technologies: form.technologies.split(",").map((t) => t.trim()).filter(Boolean),
      author: { id: user?.id, name: user?.name },
    };
    const res = await api.submitProject(payload);
    setLoading(false);
    setResult(res);
    // In production, navigate or show success
  };

  return (
    <div>
      <h2>Submit Project</h2>
      <form onSubmit={handleSubmit} className="card">
        <div className="form-row">
          <label>Title</label>
          <input name="title" value={form.title} onChange={handleChange} required />
        </div>
        <div className="form-row">
          <label>Description</label>
          <textarea name="description" value={form.description} onChange={handleChange} rows={4} />
        </div>
        <div className="form-row">
          <label>Faculty</label>
          <input name="faculty" value={form.faculty} onChange={handleChange} />
        </div>
        <div className="form-row">
          <label>Department</label>
          <input name="department" value={form.department} onChange={handleChange} />
        </div>
        <div className="form-row">
          <label>Category</label>
          <input name="category" value={form.category} onChange={handleChange} />
        </div>
        <div className="form-row">
          <label>Technologies (comma separated)</label>
          <input name="technologies" value={form.technologies} onChange={handleChange} />
        </div>
        <div className="form-row">
          <label>GitHub Link</label>
          <input name="github" value={form.github} onChange={handleChange} />
        </div>

        <button className="btn" type="submit" disabled={loading}>{loading ? "Submitting..." : "Submit Project"}</button>
      </form>

      {result && (
        <div style={{ marginTop: 12 }} className="card">
          <div>Project submitted to queue. Awaiting supervisor approval.</div>
          <div style={{ fontWeight: 700, marginTop: 8 }}>{result.title}</div>
        </div>
      )}
    </div>
  );
}