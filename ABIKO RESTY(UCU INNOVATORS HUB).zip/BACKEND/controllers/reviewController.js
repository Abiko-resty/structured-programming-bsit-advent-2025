const db = require('../db');

exports.reviewProject = async (req, res) => {
  const projectId = req.params.projectId;
  const { decision, comment } = req.body; // 'approved' | 'rejected' | 'changes_requested'
  try {
    await db.query('INSERT INTO reviews (project_id, supervisor_id, decision, comment, created_at) VALUES (?, ?, ?, ?, NOW())',
      [projectId, req.user.id, decision, comment || null]);

    let status = 'under_review';
    if (decision === 'approved') status = 'approved';
    else if (decision === 'rejected') status = 'rejected';
    else if (decision === 'changes_requested') status = 'submitted';

    await db.query('UPDATE projects SET status=?, supervisor_id=?, updated_at=NOW() WHERE id=?',
      [status, req.user.id, projectId]);

    res.json({ projectId, status });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};
