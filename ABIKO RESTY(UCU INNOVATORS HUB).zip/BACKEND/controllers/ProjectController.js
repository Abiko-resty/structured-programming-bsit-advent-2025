const db = require('../db');

exports.createProject = async (req, res) => {
  const { title, description, categoryId, technologies = [], githubUrl, demoUrl, year, facultyId, departmentId, team = [] } = req.body;
  const documentUrl = req.file ? `/uploads/${req.file.filename}` : null;
  try {
    const [result] = await db.query(
      `INSERT INTO projects (title, description, category_id, github_url, demo_url, year, status, student_owner_id, faculty_id, department_id, document_url)
       VALUES (?, ?, ?, ?, ?, ?, 'submitted', ?, ?, ?, ?)`,
      [title, description, categoryId, githubUrl || null, demoUrl || null, year, req.user.id, facultyId, departmentId, documentUrl]
    );

    const projectId = result.insertId;

    for (const t of technologies) {
      const [techRow] = await db.query('SELECT id FROM technologies WHERE name = ?', [t]);
      let techId = techRow[0]?.id;
      if (!techId) {
        const [newTech] = await db.query('INSERT INTO technologies (name) VALUES (?)', [t]);
        techId = newTech.insertId;
      }
      await db.query('INSERT INTO project_technologies (project_id, technology_id) VALUES (?, ?)', [projectId, techId]);
    }

    for (const member of team) {
      await db.query(
        'INSERT INTO project_team_members (project_id, name, email, role_in_project) VALUES (?, ?, ?, ?)',
        [projectId, member.name, member.email || null, member.role_in_project || null]
      );
    }

    res.status(201).json({ id: projectId });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};

exports.getProjects = async (req, res) => {
  const { status, facultyId, departmentId, categoryId, year, technology, q } = req.query;
  const params = [];
  const where = [];

  if (status) { where.push('p.status = ?'); params.push(status); }
  if (facultyId) { where.push('p.faculty_id = ?'); params.push(facultyId); }
  if (departmentId) { where.push('p.department_id = ?'); params.push(departmentId); }
  if (categoryId) { where.push('p.category_id = ?'); params.push(categoryId); }
  if (year) { where.push('p.year = ?'); params.push(year); }
  if (q) { where.push('(p.title LIKE ? OR p.description LIKE ?)'); params.push(`%${q}%`, `%${q}%`); }
  if (technology) {
    where.push('EXISTS (SELECT 1 FROM project_technologies pt JOIN technologies t ON pt.technology_id=t.id WHERE pt.project_id=p.id AND t.name = ?)');
    params.push(technology);
  }

  const sql = `
    SELECT p.id, p.title, p.year, p.status, p.github_url, p.demo_url, p.document_url,
           c.name AS category, f.name AS faculty, d.name AS department
    FROM projects p
    LEFT JOIN categories c ON p.category_id=c.id
    LEFT JOIN faculties f ON p.faculty_id=f.id
    LEFT JOIN departments d ON p.department_id=d.id
    ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
    ORDER BY p.created_at DESC
    LIMIT 50
  `;

  try {
    const [rows] = await db.query(sql, params);
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};

exports.getProjectById = async (req, res) => {
  const id = req.params.id;
  try {
    const [rows] = await db.query(
      `SELECT p.*, c.name AS category, f.name AS faculty, d.name AS department
       FROM projects p
       LEFT JOIN categories c ON p.category_id=c.id
       LEFT JOIN faculties f ON p.faculty_id=f.id
       LEFT JOIN departments d ON p.department_id=d.id
       WHERE p.id = ?`, [id]
    );
    const project = rows[0];
    if (!project) return res.status(404).json({ error: 'Not found' });

    if (project.status !== 'approved' && !['admin', 'supervisor'].includes(req.user?.role) && req.user?.id !== project.student_owner_id) {
      return res.status(403).json({ error: 'Forbidden' });
    }

    const [techs] = await db.query(
      `SELECT t.name FROM project_technologies pt JOIN technologies t ON pt.technology_id=t.id WHERE pt.project_id=?`, [id]
    );
    const [team] = await db.query(`SELECT name, email, role_in_project FROM project_team_members WHERE project_id=?`, [id]);
    res.json({ ...project, technologies: techs.map(t => t.name), team });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};
