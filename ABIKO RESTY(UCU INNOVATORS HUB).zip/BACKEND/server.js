const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
require('dotenv').config();

const authRoutes = require('./routes/auth');
const projectRoutes = require('./routes/projects');
const reviewRoutes = require('./routes/reviews');

const app = express();

app.use(cors());
app.use(helmet());
app.use(express.json());
app.use(morgan('dev'));
app.use('/uploads', express.static('uploads'));

app.use('/api/auth', authRoutes);
app.use('/api/projects', projectRoutes);
app.use('/api/reviews', reviewRoutes);

app.get('/health', (req, res) => res.json({ status: 'ok' }));

const port = process.env.PORT || 5000;

const startServer = async () => {
  try {
    app.listen(port, () => console.log(`UCU Innovators Hub API running on port ${port}`));
  } catch (e) {
    console.error('Failed to start server:', e);
    process.exit(1);
  }
};

startServer();

module.exports = app;