const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const { reviewProject } = require('../controllers/reviewController');

router.post('/:projectId', requireAuth(['supervisor','admin']), reviewProject);

module.exports = router;
