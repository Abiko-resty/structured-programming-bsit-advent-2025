const express = require('express');
const router = express.Router();
const upload = require('../utils/upload.js');
const { requireAuth } = require('../middleware/auth.js');
const { createProject, getProjects, getProjectById } = require('../controllers/ProjectController');

router.get('/', getProjects);
router.get('/:id', requireAuth(), getProjectById);
router.post('/', requireAuth(['student']), upload.single('document'), createProject);

module.exports = router;
